import { createFileRoute } from "@tanstack/react-router";
import { Page } from "@/components/choose/page";

export const Route = createFileRoute("/privacy")({ component: Privacy });

function Privacy() {
  return (
    <Page title="Privacy">
      <p>Nothing is stored, so there is no export and no delete.</p>
      <p>The line stays in the tab until you leave. It is not sent to a model off this device. It is not posted out of the window.</p>
      <p>No analytics, no ad script, no third-party tracker.</p>
      <p>Weights may be fetched once from Hugging Face. The wasm comes from the app host. During a take, the page counts network calls. Zero means nothing left this device.</p>
      <p>There is no sign-in page. These pages are open to crawlers.</p>
      <p>A mailbox, a password, or a phone number is not kept.</p>
    </Page>
  );
}
